from pathlib import Path
import subprocess,hashlib,json,difflib,os
root=Path('/mnt/data/s23');out=Path('/mnt/data/live-evidence/mutations');out.mkdir(exist_ok=True)
path=root/'scripts/check_live_evidence.py';original=path.read_text()
experiments=[
 ('ignore-ramp-measurements',"passed = mean <= .75 and peak <= 2 and levels >= 600 and colour <= 12","passed = bool(value.get('passed'))","LiveEvidenceTests.test_tc_p003_04_actual_negative_measurements_required"),
 ('ignore-publication-identity',"underlying['publication']['mediaIdentity'] == underlying['full_decode']['mediaIdentity']","True","LiveEvidenceTests.test_tc_p003_07_publication_identity_must_match"),
 ('allow-sensor-claim',"('sourcePixelsStored', 'pixelSourceComparison', 'physicalCameraCertified')","('sourcePixelsStored', 'pixelSourceComparison')","LiveEvidenceTests.test_tc_p003_01_physical_claim_is_not_decoded_ramp")]
records=[]
try:
 for label,old,new,test in experiments:
  assert original.count(old)==1,label
  mutant=original.replace(old,new)
  path.write_text(mutant)
  (out/(label+'.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(True),mutant.splitlines(True),fromfile='original',tofile='mutant')))
  command=['python3','-B','-m','unittest','test_live_evidence.'+test,'-v']
  result=subprocess.run(command,cwd=root/'scripts/tests',capture_output=True,text=True,timeout=20,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  text=result.stdout+result.stderr;(out/(label+'.log')).write_text(text)
  assert result.returncode==1 and 'AssertionError' in text and '\nERROR:' not in text,(label,text)
  records.append({'mutation':label,'exit_code':result.returncode,'test':test,'result':'detected_by_assertion','sha256':hashlib.sha256(mutant.encode()).hexdigest()})
finally:path.write_text(original)
(out/'manifest.json').write_text(json.dumps({'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'restored':path.read_text()==original,'experiments':records},indent=2))
print(json.dumps(records,indent=2))
