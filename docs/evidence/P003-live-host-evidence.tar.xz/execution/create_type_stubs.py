from pathlib import Path
import re,collections
root=Path('/mnt/data/s23');out=Path('/mnt/data/android-typecheck/stubs');out.mkdir(exist_ok=True)
(out/'BuildConfig.kt').write_text('package com.s23log.probe\nobject BuildConfig { const val SOURCE_REVISION="826ad1ed5de00efd36393aefa5ecee7b470edc00"; const val VERSION_NAME="compile-only" }\n')
(out/'FileProvider.kt').write_text('package androidx.core.content\nobject FileProvider { fun getUriForFile(context:android.content.Context, authority:String, file:java.io.File):android.net.Uri = throw UnsupportedOperationException("Compile-only stub") }\n')
resources=collections.defaultdict(set)
for p in (root/'app/src/main/java').rglob('*.kt'):
 for kind,name in re.findall(r'(?<!android\.)(?<!\w)R\.([a-zA-Z]+)\.([a-zA-Z_0-9]+)',p.read_text()):resources[kind].add(name)
s='package com.s23log.probe\nobject R {\n'
for kind,names in resources.items():s+='object '+kind+' {\n'+'\n'.join('const val '+name+' = '+str(i+1) for i,name in enumerate(sorted(names)))+'\n}\n'
(out/'R.kt').write_text(s+'}\n')
