package org.junit;
// Compile-only method signatures. These methods are never used as test execution.
public class Assert {
 public static void assertTrue(boolean v){throw new UnsupportedOperationException();}
 public static void assertTrue(String m,boolean v){throw new UnsupportedOperationException();}
 public static void assertFalse(boolean v){throw new UnsupportedOperationException();}
 public static void assertFalse(String m,boolean v){throw new UnsupportedOperationException();}
 public static void assertEquals(Object a,Object b){throw new UnsupportedOperationException();}
 public static void assertEquals(long a,long b){throw new UnsupportedOperationException();}
 public static void assertEquals(String m,Object a,Object b){throw new UnsupportedOperationException();}
 public static void assertArrayEquals(byte[] a,byte[] b){throw new UnsupportedOperationException();}
 public static void assertNull(Object a){throw new UnsupportedOperationException();}
 public static void assertNotNull(Object a){throw new UnsupportedOperationException();}
 public static void fail(String m){throw new UnsupportedOperationException();}
}
