package androidx.core.view
class Insets(val left:Int,val top:Int,val right:Int,val bottom:Int)
class WindowInsetsCompat {
    fun getInsets(mask:Int):Insets = throw UnsupportedOperationException("Compile-only stub")
    object Type { fun systemBars():Int=throw UnsupportedOperationException();fun displayCutout():Int=throw UnsupportedOperationException();fun ime():Int=throw UnsupportedOperationException() }
}
object WindowCompat { fun setDecorFitsSystemWindows(window:android.view.Window, fits:Boolean):Unit = throw UnsupportedOperationException("Compile-only stub") }
object ViewCompat { fun setOnApplyWindowInsetsListener(view:android.view.View, listener:(android.view.View,WindowInsetsCompat)->WindowInsetsCompat):Unit=throw UnsupportedOperationException("Compile-only stub") }
