package com.s23log.probe
object BuildConfig { const val SOURCE_REVISION="826ad1ed5de00efd36393aefa5ecee7b470edc00"; const val VERSION_NAME="compile-only" }
